
// const expand = document.getElementById('expand');

const observer = new IntersectionObserver((entries)=>{
    entries.forEach((entry)=>{
        console.log(entry)
        if(entry.isIntersecting){
            entry.target.classList.add('show');

        }else{
            entry.target.classList.remove('show');
        }
    });
});

const gallery = document.querySelectorAll('.hidden');
gallery.forEach((el)=>observer.observe(el));


const socialmedia =document.getElementsByClassName('socialmedia');

function Expand() {
    console.log('yes');
    const tags = document.getElementsByClassName('tags');
    for (let i = 0; i < tags.length; i++) {
        tags[i].classList.toggle('hide');
    }
}

const dropdownbtn = document.getElementById('dropdownbtn');
const dropdowncontent = document.getElementsByClassName('dropdown-content')[0];

dropdownbtn.addEventListener('click', (e) => {
    console.log(e.target);
    dropdowncontent.classList.toggle('show1') ;
});



const eb1 = document.getElementById('eb1');
const boxes = document.getElementsByClassName('box');
const boxes2 =document.getElementsByClassName('box2');

eb1.addEventListener('click', () => {
    console.log('yes');
    for (let i = 0; i < boxes2.length; i++) {
       
        boxes2[i].style.display='flex';
      
    }
});
const eb2 = document.getElementById('eb2');

eb2.addEventListener('click', () => {
    console.log("hey");
    for (let i = boxes2.length - 1; i >= 0; i--) {
        boxes2[i].style.display = 'none';
    }
});


for (let i = 0; i < boxes.length; i++) {
    boxes[i].addEventListener("mouseover", (e) => {
        const insideBox = e.currentTarget.querySelector(".insidebox");
        insideBox.style.display = 'block';
    });
}

for (let i = 0; i < boxes2.length; i++) {
    boxes2[i].addEventListener("mouseover", (e) => {
        const insideBox = e.currentTarget.querySelector(".insidebox");
        insideBox.style.display = 'block';
    });
}
for (let i = 0; i < boxes.length; i++) {
    boxes[i].addEventListener("mouseout", (e) => {
        const insideBox = e.currentTarget.querySelector(".insidebox");
        insideBox.style.display = 'none';
    });
}

for (let i = 0; i < boxes2.length; i++) {
    boxes2[i].addEventListener("mouseout", (e) => {
        const insideBox = e.currentTarget.querySelector(".insidebox");
        insideBox.style.display = 'none';
    });
}




const menu = document.querySelector(".hamburgercontent");
const hamburger = document.querySelector("#hamburger");

hamburger.addEventListener("click", function() {
    // Change CSS properties using JavaScript
    console.log("hey");
   
    if (menu.style.display === "flex") {
        menu.style.display = "none";
    } else {
        menu.style.display = "flex";
    }
});

    

    










