const observer = new IntersectionObserver((entries)=>{
    entries.forEach((entry)=>{
        console.log(entry)
        if(entry.isIntersecting){
            entry.target.classList.add('show');

        }else{
            entry.target.classList.remove('show');
        }
    });
});

const gallery = document.querySelectorAll('.hidden');
gallery.forEach((el)=>observer.observe(el));


const dropdownbtn = document.getElementById('dropdownbtn');
const dropdowncontent = document.getElementsByClassName('dropdown-content')[0];

dropdownbtn.addEventListener('click', (e) => {
    console.log(e.target);
    dropdowncontent.classList.toggle('show1') ;
});
const menu = document.querySelector(".hamburgercontent");
const hamburger = document.querySelector("#hamburger");

hamburger.addEventListener("click", function() {
    // Change CSS properties using JavaScript
    console.log("hey");
   
    if (menu.style.display === "flex") {
        menu.style.display = "none";
    } else {
        menu.style.display = "flex";
    }
});
