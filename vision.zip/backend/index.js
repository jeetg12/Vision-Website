

const { log } = require('console');
const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const app = express();
const port = 8000;

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/vision-data')
    .then(() => {
        console.log("Mongoose connected");
    })
    .catch((err) => {
        console.log("Error", err);
    });

// User Schema
const userSchema = new mongoose.Schema({
    firstname: {
        type: String,
        required: true,
    },
    lastname: {
        type: String,
    },
    email: {
        type: String,
        required: true,
        unique: true
    },
    phone: {
        type: String,
        // required: true,
    },
    message: {
        type: String,
    }
});

const UserData = mongoose.model('User', userSchema);

// Middleware
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'contact')));

// Routes
app.get("/contact", (req, res) => {
    res.sendFile(path.join(__dirname, 'contact', 'index.html'));
});

app.post("/contact", async (req, res) => {
    try {
        const { firstname, lastname, email, phone, message } = req.body;
        await UserData.create({
            firstname,
            lastname,
            email,
            phone,
            message,
        });
        console.log("Submitted");
        res.redirect('index.html');
    } catch (error) {
        console.error("Error submitting contact form:", error);
        res.status(500).json("Error submitting form");
    }
});

// Alumni Schema
const alumniSchema = new mongoose.Schema({
    name1: {
        type: String,
        required: true,
    },
    name2: {
        type: String,
    },
    emailuser: {
        type: String,
       required: true,
    },
    position: {
        type: String,
        required: true,
    },
    URL: {
        type: String,
        required: true,
    },
    graduationyear: {
        type: String,
        required: true,
    }
});

const AlumniData = mongoose.model('Alumni', alumniSchema);

app.get("/contactuser", (req, res) => {
    res.sendFile(path.join(__dirname, 'contact', 'index.html'));
});

app.post("/contactuser", async (req, res) => {
    try {
        const { name1, name2, emailuser, position, URL, graduationyear } = req.body;
        await AlumniData.create({
            name1,
            name2,
            emailuser,
            position,
            URL,
            graduationyear
        });
        console.log("Submitted");
        res.redirect('index.html');
    } catch (error) {
        console.error("Error submitting contact user form:", error);
        res.status(500).json("Error submitting form");
    }
});



const EventSchema = new mongoose.Schema({
    event: {
        type: String,
        required: true,
    },
    description: {
        type: String,
    },
    date: {
        type: String,
       required: true,
    },
    eventURL: {
        type: String,
        required: true,
    },
   
});

const EventData = mongoose.model('Event', EventSchema);

app.get("/contactevent", (req, res) => {
    res.sendFile(path.join(__dirname, 'contact', 'index.html'));
});

app.post("/contactevent", async (req, res) => {
    try {
        const { event, description, date,eventURL } = req.body;
        await EventData.create({
            event,
            description,
            date,
            eventURL
        });
        console.log("Submitted");
       res.redirect('index.html');
    } catch (error) {
        console.error("Error submitting contact user form:", error);
        res.status(500).json("Error submitting form");
    }
});

// Start server
app.listen(port, () => {
    console.log(`Server started on port ${port}`);
});
