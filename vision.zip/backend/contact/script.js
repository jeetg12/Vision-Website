const dropdownbtn = document.getElementById('dropdownbtn');
const dropdowncontent = document.getElementsByClassName('dropdown-content')[0];

dropdownbtn?.addEventListener('click', (e) => {
    console.log(e.target);
    dropdowncontent.classList.toggle('show1');
});

const newuser = document.getElementById('newuser');
const newevent = document.getElementById('newevent');
const userform = document.querySelector('.userform');
const eventform = document.querySelector('.eventform');
const container= document.querySelector('.container');
const back1 = document.getElementById('back1');
const back2 = document.getElementById('back2');




newuser?.addEventListener('click', (e) => {
    e.preventDefault(); 
    console.log("yeah");

    if (userform) {
        userform.style.display = 'block';
        container.style.display ='none';
       
      
      
    }
});

newevent?.addEventListener('click', (e) => {
    e.preventDefault(); 
    console.log("yeah");

    if (eventform) {
        eventform.style.display = 'block';
        container.style.display ='none';
       
      
      
    }
});
back1.addEventListener('click', (event) => {
    event.preventDefault(); 
    if (eventform && container) {
        eventform.style.display = 'none';
        container.style.display = "block";
    }
});
back2.addEventListener('click', (event) => {
    event.preventDefault(); 
    if (userform && container) {
        userform.style.display = 'none';
        container.style.display = "block";
    }
});


const menu = document.querySelector(".hamburgercontent");
const hamburger = document.querySelector("#hamburger");

hamburger.addEventListener("click", function() {
    // Change CSS properties using JavaScript
    console.log("hey");
   
    if (menu.style.display === "flex") {
        menu.style.display = "none";
    } else {
        menu.style.display = "flex";
    }
});
